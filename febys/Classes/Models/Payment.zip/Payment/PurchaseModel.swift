//
//  PurchaseModel.swift
//  febys
//
//  Created by Faisal Shahzad on 18/1/2022.
//

import UIKit
import CoreLocation

class PurchaseModel {
    static let shared = PurchaseModel()
    
    var onTransactionComplete :((TransactionResponse) -> ())?
    var onTransactionFailure : ((FebysError) -> ())?
    var onPurchaseComplete : ((OrderResponse) -> ())?
    
    //MARK: CONVERSION
    func convertWalletIntoCurrent(currency: String, completion: @escaping ( _ success: (String,Float))->Void)  {
        let wallet = UserInfo.fetch()?.wallet
        let walletBalance = Float(wallet?.availableBalance ?? 0.0)
        let walletCurrency = wallet?.currency
        let productCurrency = currency
        
        if walletCurrency == productCurrency {
            completion((productCurrency, Float(walletBalance)))
            return
        }
        
        let bodyParams = [ParameterKeys.to: walletCurrency,
                          ParameterKeys.from: productCurrency]
        
        PriceService.shared.getConversionRate(body: bodyParams as [String : Any]) { response in
            switch response {
            case .success(let rate):
                let amount = Float(rate.conversion_rate ?? 0.0)
                let convertedAmount = walletBalance * (1/amount)
                let newConvertedAmount = (floor(convertedAmount * 100)) / 100

                completion((productCurrency, Float(newConvertedAmount)))
            case .failure(let error):
                print(error)
            }
        }
    }
    
    
    func convertAmount(price: Price, completion: @escaping ( _ success: (Float,Float))->Void)  {
        
        let userWallet = Float(UserInfo.fetch()?.wallet?.availableBalance ?? 0.0)
        let walletCurrency = UserInfo.fetch()?.wallet?.currency
        let productCurrency = price.currency
        
        if walletCurrency == productCurrency {
            completion((Float(userWallet),1))
            return
        }
        
        let bodyParams = [ParameterKeys.to: walletCurrency,
                          ParameterKeys.from: productCurrency]
        
        PriceService.shared.getConversionRate(body: bodyParams as [String : Any]) { response in
            switch response {
            case .success(let rate):
                let conversionRate = Float(rate.conversion_rate ?? 0.0)
                let convertedAmount = userWallet * (1/conversionRate)
                let newConvertedAmount = (floor(convertedAmount * 100)) / 100

                completion((Float(newConvertedAmount),conversionRate))
            case .failure(let error):
                print(error)
            }
        }
    }
    
    func createBillAmount(_ order: Order) -> Price {
        var amount = 0.0
        if order.isSplitPayment && order.isSplitAmountDeducted{
            amount = order.amountAfterDeductionForSplit
        }else{
            amount = order.billAmount?.value ?? 0.0
        }
        var price = Price()
        price.currency = order.billAmount?.currency ?? "USD"
        price.value = amount.round(to: 2)
        return price
    }
    
    //MARK: PLACE ORDER
    func placeOrder(order: Order?, items: [[String:Any]]?, messages: [[String:Any]]?)  {
        
        let bodyParams = [ ParameterKeys.transaction_ids: self.prepareTransactionIds(of: order),
                           ParameterKeys.shipping_detail: order?.shippingDetail?.toDictionary ?? [:],
                           ParameterKeys.items: items ?? [:],
                           ParameterKeys.messages: messages ?? [:],
                           ParameterKeys.voucherCode: order?.voucher?.code ?? [:]] as [String : Any]
        
        OrderService.shared.placeOrder(body: bodyParams) { response in
            switch response {
            case .success(let orderResponse):
                self.onPurchaseComplete?(orderResponse)
            case .failure(let error):
                self.onTransactionFailure?(error)
            }
        }
    }
    
    
    func prepareTransactionIds(of order: Order?) -> [String] {
        var ids: [String] = []
        _ = order?.transactions?.compactMap({ transaction in
            ids.append(transaction.id ?? "")
        })
        return ids
    }
    
    //MARK: WALLET
    func transactionThroughWallet(amount: Double, currency: String)  {
        let bodyParams = [ParameterKeys.amount: amount,
                          ParameterKeys.currency: currency,
                          ParameterKeys.purpose: Constants.PRODUCT_PURCHASE] as [String : Any]
        
        WalletService.shared.processWalletPayment(body: bodyParams) { response in
            switch response {
            case .success(let transactionResponse):
                self.onTransactionComplete?(transactionResponse)
                break
            case .failure(let error):
                self.onTransactionFailure?(error)
            }
        }
    }
    
    //MARK: PAYSTACK
      func initiatePayStackPayment(billAmount: Price, purpose: String, onComplete: @escaping ((Result<PayStackResponse, FebysError>)->Void)) {
          let bodyParams = [ParameterKeys.amount: billAmount.value ?? 0.0,
                            ParameterKeys.currency: billAmount.currency ?? "USD",
                            ParameterKeys.purpose: purpose] as [String : Any]
          
          PayStackService.shared.requestPayStack(body: bodyParams) { response in
              switch response {
              case .success(let request):
                  onComplete(.success(request))
                  break
              case .failure(let error):
                  onComplete(.failure(error))
                  break
              }
          }
      }
  
      func checkPayStackStatus(payStack: PayStackResponse?, onComplete: @escaping ((Result<String, FebysError>)->Void)){
  
          PayStackService.shared.getPayStackStatus(requestId: payStack?.transactionRequest?.reference ?? "") { response in
              switch response {
              case .success(let transactionResponse):
                  if let status = transactionResponse.transaction?.status {
                      switch status {
                      case "PENDING_CLAIM":
                          self.onTransactionComplete?(transactionResponse)
                          onComplete(.success(status))
                      case "REQUESTED":
                          onComplete(.success(""))
                      default:
                          break
                      }
                  }else{
                      onComplete(.success(""))
                  }
                  break
              case .failure(let error):
                  onComplete(.failure(error))
                  break
              }
          }
      }
      
    //MARK: PAYPAL
    
    func transactionThroughPaypal(orderId: String, purpose: String)  {
        
        let bodyParams = [ParameterKeys.order_id: orderId,
                          ParameterKeys.purpose: purpose] as [String : Any]
        
        PayPalService.shared.proceedPaypalPayment(body: bodyParams) { response in
            switch response {
            case .success(let transactionResponse):
                self.onTransactionComplete?(transactionResponse)
                break
            case .failure(let error):
                self.onTransactionFailure?(error)
                break
            }
        }
    }  
}

extension Encodable {
  var toDictionary: [String: Any]? {
    guard let data = try? JSONEncoder().encode(self) else { return nil }
    return (try? JSONSerialization.jsonObject(with: data, options: .allowFragments)).flatMap { $0 as? [String: Any] }
  }
}
