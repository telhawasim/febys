//
//  ConversionRate.swift
//  febys
//
//  Created by Faisal Shahzad on 18/01/2022.
//

import Foundation
struct ConversionRate : Codable {
    let conversion_rate : Double?
}
