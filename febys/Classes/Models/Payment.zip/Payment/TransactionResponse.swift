import Foundation

struct TransactionResponse : Codable {
	let transaction : Transaction?

	enum CodingKeys: String, CodingKey {
		case transaction = "transaction"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		transaction = try values.decodeIfPresent(Transaction.self, forKey: .transaction)
	}

}
