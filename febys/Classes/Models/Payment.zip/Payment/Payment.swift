//
//  Payment.swift
//  febys
//
//  Created by Abdul Kareem on 08/10/2021.
//

import Foundation

struct Payment{
    let paymentID: String?
    let paymentName: String?
    let paymentImage: String?
}
